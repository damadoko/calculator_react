import React from "react";
import classes from "./Buttons.module.css";

import Button from "./Button/Button";

const Buttons = (props) => {
  const { buttonList, newNum, multi } = props;
  const ButtonsList = buttonList.map((btn) => (
    <Button key={btn} input={btn} newNum={newNum} multi={multi} />
  ));
  return <div className={classes.Buttons}>{ButtonsList}</div>;
};

export default Buttons;
